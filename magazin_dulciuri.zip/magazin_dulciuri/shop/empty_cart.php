<?php
session_start();
require_once "../includes/DBController.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION["user_id"];
$db = new DBController();

$db->updateDB("DELETE FROM tbl_cart WHERE user_id = ?", [$user_id]);

header("Location: cart.php");
exit;
