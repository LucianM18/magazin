<link rel="stylesheet" href="../style.css">

<div class="container">
    <h2>Plată realizată cu succes! 🎉</h2>

    <p style="text-align:center;">
        Comanda a fost procesată.<br>
        Vei primi un email de confirmare.
    </p>

    <a href="categories.php">
        <button>Înapoi în magazin</button>
    </a>
</div>
