
<?php
session_start();

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: checkout.php");
    exit;
}

$name = $_POST["name"];
$email = $_POST["email"];
$total = $_POST["total"];
?>

<link rel="stylesheet" href="../style.css">

<div class="container">
    <h2>Plată cu cardul</h2>

    <p style="text-align:center; font-size:18px;">
        Total: <strong><?php echo htmlspecialchars($total); ?> lei</strong>
    </p>

    <form method="post" action="payment_process.php">
        <input type="hidden" name="name" value="<?php echo htmlspecialchars($name); ?>">
        <input type="hidden" name="email" value="<?php echo htmlspecialchars($email); ?>">
        <input type="hidden" name="total" value="<?php echo htmlspecialchars($total); ?>">

        <label>Număr card</label>
        <input type="text" name="card_number" placeholder="1234 5678 9012 3456" required maxlength="19">

        <label>Data expirării</label>
        <input type="text" name="card_expiry" placeholder="MM/YY" required maxlength="5">

        <label>CVV</label>
        <input type="password" name="card_cvv" placeholder="123" required maxlength="4">

        <button type="submit">Plătește acum</button>
    </form>

    <a href="checkout.php" style="display:block; text-align:center; margin-top:15px;">Înapoi</a>
</div>
