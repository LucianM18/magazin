<?php
session_start();
require_once "../includes/DBController.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $cart_id = $_POST["cart_id"];
    $quantity = $_POST["quantity"];

    if ($quantity < 1) {
        $quantity = 1; 
    }

    $db = new DBController();

    $db->updateDB(
        "UPDATE tbl_cart SET quantity = ? WHERE id = ?",
        [$quantity, $cart_id]
    );
}

header("Location: cart.php");
exit;
