
<?php
session_start();
require_once "../includes/DBController.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION["user_id"];
$db = new DBController();

$cart = $db->getDBResult("
    SELECT tbl_cart.id, tbl_cart.quantity, products.name, products.price 
    FROM tbl_cart 
    JOIN products ON tbl_cart.product_id = products.id
    WHERE tbl_cart.user_id = ?
", [$user_id]);
?>

<link rel="stylesheet" href="../style.css">


<h2>Coșul tău de cumpărături</h2>

<?php if (empty($cart)): ?>
    <p>Coșul este gol!</p>
    <a href="categories.php">Continuă cumpărăturile</a><br>
    <a href="logout.php">Logout</a>
    <?php exit; ?>
<?php endif; ?>

<table border="1" cellpadding="10">
    <tr>
        <th>Produs</th>
        <th>Preț</th>
        <th>Cantitate</th>
        <th>Subtotal</th>
        <th>Acțiuni</th>
    </tr>

    <?php foreach ($cart as $item): ?>
        <tr>
            <td><?php echo htmlspecialchars($item["name"]); ?></td>
            <td><?php echo $item["price"]; ?> lei</td>

            <td>
                <form action="update_cart.php" method="post">
                    <input type="hidden" name="cart_id" value="<?php echo $item["id"]; ?>">
                    <input type="number" name="quantity" value="<?php echo $item["quantity"]; ?>" min="1">
                    <button type="submit">Actualizează</button>
                </form>
            </td>

            <td><?php echo $item["price"] * $item["quantity"]; ?> lei</td>

            <td>
                <a href="remove_from_cart.php?id=<?php echo $item['id']; ?>">Șterge</a>
            </td>
        </tr>
    <?php endforeach; ?>
</table>

<br>

<a href="empty_cart.php">Golește coșul</a><br>
<a href="categories.php">Continuă cumpărăturile</a><br>
<a href="checkout.php">Mergi la plată</a><br>
<a href="logout.php">Logout</a>
