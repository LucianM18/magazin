
<?php
session_start();
require_once "../includes/DBController.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION["user_id"];
$db = new DBController();

$cart = $db->getDBResult("
    SELECT tbl_cart.quantity, products.name, products.price 
    FROM tbl_cart
    JOIN products ON tbl_cart.product_id = products.id
    WHERE tbl_cart.user_id = ?
", [$user_id]);

if (empty($cart)) {
    echo "Coșul este gol!";
    echo "<br><a href='categories.php'>Înapoi în magazin</a>";
    exit;
}

$total = 0;
foreach ($cart as $item) {
    $total += $item["quantity"] * $item["price"];
}
?>

<link rel="stylesheet" href="../style.css">


<h2>Finalizare comandă</h2>

<p>Total de plată: <strong><?php echo $total; ?> lei</strong></p>

<form method="post" action="payment_card.php">
    <label>Nume complet:</label><br>
    <input type="text" name="name" required><br><br>

    <label>Email pentru confirmare:</label><br>
    <input type="email" name="email" required><br><br>

    <input type="hidden" name="total" value="<?php echo $total; ?>">

    <button type="submit">Continuă la plata cu cardul</button>
</form>

<br>
<a href="cart.php">Înapoi la coș</a>
