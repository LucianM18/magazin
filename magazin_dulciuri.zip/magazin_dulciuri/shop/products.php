
<?php
session_start();
require_once "../includes/DBController.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

if (!isset($_GET["category_id"])) {
    exit("Categorie invalidă!");
}

$category_id = $_GET["category_id"];
$db = new DBController();

$produse = $db->getDBResult("SELECT * FROM products WHERE category_id = ?", [$category_id]);

$categorie = $db->getDBResult("SELECT name FROM categories WHERE id = ?", [$category_id]);
$categorie = $categorie ? $categorie[0]["name"] : "Categorie necunoscută";
?>

<link rel="stylesheet" href="../style.css">


<h2>Produse din categoria: <?php echo htmlspecialchars($categorie); ?></h2>

<div style="width:90%; margin:0 auto; display:flex; flex-wrap:wrap; justify-content:center;">
<?php foreach ($produse as $prod): ?>
    
    <div class="product-card">
        
        <?php if (!empty($prod["image"])): ?>
            <img src="img/<?php echo htmlspecialchars($prod['image']); ?>" class="prod-img">
        <?php else: ?>
            <img src="img/default.jpg" class="prod-img">
        <?php endif; ?>

        <h3><?php echo htmlspecialchars($prod["name"]); ?></h3>
        <p><?php echo htmlspecialchars($prod["price"]); ?> lei</p>

        <a href="add_to_cart.php?id=<?php echo $prod['id']; ?>">
            <button>Adaugă în coș</button>
        </a>

    </div>

<?php endforeach; ?>
</div>

<div style="clear:both; width:90%; margin:30px auto; text-align:center;">
    <a href="categories.php"><button>Înapoi la categorii</button></a><br><br>
    <a href="cart.php"><button>Vezi coșul</button></a><br><br>
    <a href="logout.php"><button>Logout</button></a>
</div>
