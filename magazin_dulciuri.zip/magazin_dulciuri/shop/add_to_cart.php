<?php
session_start();
require_once "../includes/DBController.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

if (!isset($_GET["id"])) {
    exit("Produs invalid!");
}

$user_id = $_SESSION["user_id"];
$product_id = $_GET["id"];

$db = new DBController();

$exista = $db->getDBResult(
    "SELECT * FROM tbl_cart WHERE user_id = ? AND product_id = ?",
    [$user_id, $product_id]
);

if ($exista) {
    $cantitateNoua = $exista[0]["quantity"] + 1;
    $db->updateDB(
        "UPDATE tbl_cart SET quantity = ? WHERE user_id = ? AND product_id = ?",
        [$cantitateNoua, $user_id, $product_id]
    );
} else {
    $db->updateDB(
        "INSERT INTO tbl_cart (user_id, product_id, quantity) VALUES (?, ?, 1)",
        [$user_id, $product_id]
    );
}

header("Location: cart.php");
exit;
