
<?php
session_start();
require_once "../includes/DBController.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

$db = new DBController();

$categorii = $db->getDBResult("SELECT * FROM categories");
?>

<link rel="stylesheet" href="../style.css">


<h2>Categorii de produse</h2>

<ul>
    <?php foreach ($categorii as $cat): ?>
        <li>
            <a href="products.php?category_id=<?php echo $cat['id']; ?>">
                <?php echo htmlspecialchars($cat['name']); ?>
            </a>
        </li>
    <?php endforeach; ?>
</ul>

<a href="logout.php">Logout</a>
