
<?php
require_once "../includes/DBController.php";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = $_POST["username"];
    $password = password_hash($_POST["password"], PASSWORD_DEFAULT);

    $db = new DBController();

    $query = "INSERT INTO users (username, password) VALUES (?, ?)";
    $db->updateDB($query, [$username, $password]);

    header("Location: login.php");
    exit;
}
?>

<link rel="stylesheet" href="../style.css">



<h2>Înregistrare utilizator</h2>

<form method="post">
    <label>Username:</label>
    <input type="text" name="username" required><br><br>

    <label>Parolă:</label>
    <input type="password" name="password" required><br><br>

    <button type="submit">Creează cont</button>
</form>
