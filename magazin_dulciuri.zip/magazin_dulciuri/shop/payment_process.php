<?php
session_start();
require_once "../includes/DBController.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION["user_id"];

$name = $_POST["name"];
$email = $_POST["email"];
$total = $_POST["total"];

$db = new DBController();

$cart = $db->getDBResult("
    SELECT tbl_cart.id, tbl_cart.product_id, tbl_cart.quantity, products.price, products.name
    FROM tbl_cart
    JOIN products ON tbl_cart.product_id = products.id
    WHERE tbl_cart.user_id = ?
", [$user_id]);

if (empty($cart)) {
    header("Location: cart.php");
    exit;
}

$db->updateDB(
    "INSERT INTO orders (user_id, email, total) VALUES (?, ?, ?)",
    [$user_id, $email, $total]
);

$order_id = $db->getLastInsertedID();

foreach ($cart as $item) {
    $db->updateDB(
        "INSERT INTO order_items (order_id, product_id, quantity, price)
         VALUES (?, ?, ?, ?)",
        [$order_id, $item["product_id"], $item["quantity"], $item["price"]]
    );
}

$db->updateDB("DELETE FROM tbl_cart WHERE user_id = ?", [$user_id]);

require "../email/send_order_email.php";

header("Location: payment_success.php");
exit;
