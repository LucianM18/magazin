
<?php
session_start();
require_once "../includes/DBController.php";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    $db = new DBController();
    $query = "SELECT * FROM users WHERE username = ?";
    $result = $db->getDBResult($query, [$username]);

    if ($result) {
        $user = $result[0];
        if (password_verify($password, $user["password"])) {
            $_SESSION["user_id"] = $user["id"];
            header("Location: categories.php");
            exit;
        } else {
            echo "Parolă greșită!";
        }
    } else {
        echo "Utilizator inexistent!";
    }
}
?>

<link rel="stylesheet" href="../style.css">


<h2>Autentificare utilizator</h2>

<form method="post">
    <label>Username:</label>
    <input type="text" name="username" required><br><br>

    <label>Parolă:</label>
    <input type="password" name="password" required><br><br>

    <button type="submit">Login</button>
</form>
