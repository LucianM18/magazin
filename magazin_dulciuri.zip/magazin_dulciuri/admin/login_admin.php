<?php
session_start();
require_once "../includes/DBController.php";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    $db = new DBController();
    $query = "SELECT * FROM admini WHERE username = ?";
    $result = $db->getDBResult($query, [$username]);

    if ($result) {
        $admin = $result[0];
        if (password_verify($password, $admin["password"])) {
            $_SESSION["admin_id"] = $admin["id"];
            header("Location: admin_home.php");
            exit;
        } else {
            echo "Parolă greșită!";
        }
    } else {
        echo "Admin inexistent!";
    }
}
?>

<link rel="stylesheet" href="../style.css">


<form method="post">
    <h2>Login Admin</h2>
    <label>Username:</label>
    <input type="text" name="username" required><br><br>

    <label>Password:</label>
    <input type="password" name="password" required><br><br>

    <button type="submit">Login</button>
</form>
