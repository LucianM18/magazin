<?php
session_start();
require_once "../includes/DBController.php";

if (!isset($_SESSION["admin_id"])) {
    header("Location: login_admin.php");
    exit;
}

$db = new DBController();

$categorii = $db->getDBResult("SELECT * FROM categories");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $category_id = $_POST["category_id"];
    $name = $_POST["name"];
    $price = $_POST["price"];
    $description = $_POST["description"];

    $query = "INSERT INTO products (category_id, name, price, description) VALUES (?, ?, ?, ?)";
    $db->updateDB($query, [$category_id, $name, $price, $description]);

    echo "Produs adăugat cu succes!";
}
?>

<link rel="stylesheet" href="../style.css">


<h2>Adaugă produs nou</h2>

<form method="post">
    <label>Categorie:</label>
    <select name="category_id" required>
        <option value="">Alege categoria</option>
        <?php foreach ($categorii as $cat): ?>
            <option value="<?php echo $cat["id"]; ?>">
                <?php echo htmlspecialchars($cat["name"]); ?>
            </option>
        <?php endforeach; ?>
    </select>
    <br><br>

    <label>Nume produs:</label>
    <input type="text" name="name" required><br><br>

    <label>Preț:</label>
    <input type="number" step="0.01" name="price" required><br><br>

    <label>Descriere:</label><br>
    <textarea name="description" rows="4" cols="40"></textarea><br><br>

    <button type="submit">Salvează produs</button>
</form>
