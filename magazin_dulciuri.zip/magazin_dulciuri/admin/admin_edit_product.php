<?php
session_start();
require_once "../includes/DBController.php";

if (!isset($_SESSION["admin_id"])) {
    header("Location: login_admin.php");
    exit;
}

if (!isset($_GET["id"])) {
    exit("Produs invalid!");
}

$db = new DBController();
$id = $_GET["id"];

$produs = $db->getDBResult("SELECT * FROM products WHERE id = ?", [$id]);

if (!$produs) {
    exit("Produsul nu există!");
}

$produs = $produs[0];
$categorii = $db->getDBResult("SELECT * FROM categories");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $category_id = $_POST["category_id"];
    $name = $_POST["name"];
    $price = $_POST["price"];
    $description = $_POST["description"];

    $query = "UPDATE products SET category_id=?, name=?, price=?, description=? WHERE id=?";
    $db->updateDB($query, [$category_id, $name, $price, $description, $id]);

    echo "Produs actualizat cu succes!";
}
?>

<h2>Editare produs</h2>

<form method="post">
    <label>Categorie:</label>
    <select name="category_id" required>
        <?php foreach ($categorii as $cat): ?>
            <option value="<?php echo $cat["id"]; ?>"
                <?php if ($cat["id"] == $produs["category_id"]) echo "selected"; ?>>
                <?php echo htmlspecialchars($cat["name"]); ?>
            </option>
        <?php endforeach; ?>
    </select>
    <br><br>

    <label>Nume produs:</label>
    <input type="text" name="name" value="<?php echo htmlspecialchars($produs['name']); ?>" required><br><br>

    <label>Preț:</label>
    <input type="number" step="0.01" name="price" value="<?php echo htmlspecialchars($produs['price']); ?>" required><br><br>

    <label>Descriere:</label><br>
    <textarea name="description" rows="4" cols="40"><?php echo htmlspecialchars($produs['description']); ?></textarea><br><br>

    <button type="submit">Salvează modificările</button>
</form>
