<?php
session_start();
require_once "../includes/DBController.php";

if (!isset($_SESSION["admin_id"])) {
    header("Location: login_admin.php");
    exit;
}

$db = new DBController();

$produse = $db->getDBResult("
    SELECT products.id, products.name, products.price, categories.name AS category
    FROM products
    JOIN categories ON products.category_id = categories.id
");
?>

<h2>Lista produselor</h2>

<table border="1" cellpadding="10">
    <tr>
        <th>ID</th>
        <th>Nume</th>
        <th>Preț</th>
        <th>Categorie</th>
        <th>Acțiuni</th>
    </tr>

    <?php foreach ($produse as $prod): ?>
        <tr>
            <td><?php echo $prod["id"]; ?></td>
            <td><?php echo htmlspecialchars($prod["name"]); ?></td>
            <td><?php echo htmlspecialchars($prod["price"]); ?> lei</td>
            <td><?php echo htmlspecialchars($prod["category"]); ?></td>
            <td>
                <a href="admin_edit_product.php?id=<?php echo $prod['id']; ?>">Editează</a>
                |
                <a href="admin_delete_product.php?id=<?php echo $prod['id']; ?>"
                   onclick="return confirm('Sigur vrei să ștergi acest produs?');">
                   Șterge
                </a>
            </td>
        </tr>
    <?php endforeach; ?>
</table>
