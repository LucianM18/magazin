<?php
session_start();

if (!isset($_SESSION["admin_id"])) {
    header("Location: login_admin.php");
    exit;
}
?>

<link rel="stylesheet" href="../style.css">


<h2>Panou administrare magazin dulciuri</h2>

<ul>
    <li><a href="admin_add_product.php">Adaugă produs nou</a></li>
    <li><a href="admin_list_products.php">Lista produse (editare / ștergere)</a></li>
    <li><a href="logout_admin.php">Logout admin</a></li>
</ul>
