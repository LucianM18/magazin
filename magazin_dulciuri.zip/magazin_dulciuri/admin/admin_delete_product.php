<?php
session_start();
require_once "../includes/DBController.php";

if (!isset($_SESSION["admin_id"])) {
    header("Location: login_admin.php");
    exit;
}

if (!isset($_GET["id"])) {
    exit("Produs invalid!");
}

$id = $_GET["id"];
$db = new DBController();

$query = "DELETE FROM products WHERE id = ?";
$db->updateDB($query, [$id]);

header("Location: admin_list_products.php");
exit;
