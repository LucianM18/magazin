<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require __DIR__ . "/PHPMailer/Exception.php";
require __DIR__ . "/PHPMailer/PHPMailer.php";
require __DIR__ . "/PHPMailer/SMTP.php";

$mail = new PHPMailer(true);

try {
    $mail->isSMTP();
    $mail->Host = "smtp.gmail.com";
    $mail->SMTPAuth = true;
    $mail->Username = "lucimarasescu2004@gmail.com";
    $mail->Password = "fnqakqgwiynnqtlo";
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587;

    $mail->setFrom("lucimarasescu2004@gmail.com", "Magazin dulciuri");
    $mail->addAddress($email, $name);

    $mail->isHTML(true);
    $mail->Subject = "Confirmare comanda #" . $order_id;

    $body = "
    <h2>Îți mulțumim pentru comandă! </h2>

    <p>Bună, " . htmlspecialchars($name) . "!</p>

    <p>Comanda ta a fost înregistrată și confirmată cu succes.</p>

    <p><strong>ID Comandă:</strong> $order_id<br>
       <strong>Total:</strong> $total lei</p>

    <p>Produse comandate:</p>
    <ul>
";

foreach ($cart as $item) {
    $body .= "<li>" . htmlspecialchars($item["name"]) . " x " . $item["quantity"] . "</li>";
}

$body .= "
    </ul>

    <p>Îți mulțumim că ai ales magazinul nostru de dulciuri! <br>
    O zi frumoasă în continuare!</p>
";


    $mail->Body = $body;

   $mail->send();
echo "TRIMIS SAU INCERCAT!";

} catch (Exception $e) {
    echo "Eroare mail: " . $mail->ErrorInfo;
}

